create function st_snaptogrid(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $2)
$$;

comment on function st_snaptogrid(geometry, double precision) is 'args: geomA, size - Snap all points of the input geometry to a regular grid.';

alter function st_snaptogrid(geometry, double precision) owner to homestead;

